DYNAMIC ADMIN LITE 2.0 — বাংলা নির্দেশনা
========================================

এই প্রজেক্টে অ্যানিমেশন/ট্রানজিশন বন্ধ রাখা হয়েছে। এতে আছে Firebase Email/Password লগইন, Realtime Database-এ app settings ও remote settings সংরক্ষণ, notice, maintenance, force update, app enable/disable, APK URL এবং /users রেকর্ড দেখার/enable-disable করার ডেমো UI।

APK সরাসরি এখানে তৈরি করা হয়নি; এটি Android Studio-তে বিল্ড করার সোর্স প্রজেক্ট।

Android Studio দিয়ে APK বানানোর ধাপ:
1. ZIP Extract করুন।
2. Android Studio খুলে Open নির্বাচন করে DynamicAdminLite ফোল্ডারটি খুলুন।
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন (ইন্টারনেট লাগবে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. Build সফল হলে Android Studio-এর notification-এ Locate চাপুন। সাধারণত APK: app/build/outputs/apk/debug/app-debug.apk

Firebase সেটআপ:
1. https://console.firebase.google.com/ এ নিজের প্রজেক্ট তৈরি করুন।
2. Authentication > Sign-in method থেকে Email/Password চালু করুন এবং নিজের admin user তৈরি করুন।
3. Project settings > Your apps থেকে Web App config-এর apiKey, authDomain, databaseURL, projectId, appId (এবং ঐচ্ছিক storageBucket) অ্যাপে লিখুন।
4. Realtime Database তৈরি করুন।
5. অ্যাপে Connect Firebase চাপুন, তারপর admin email/password দিয়ে Sign in করুন।

ডেটাবেস পাথ:
/adminSettings: maintenance, forceUpdate, appEnabled, version, apkLink, notice, updatedAt, updatedBy
/remoteSettings: minVersion, supportUrl, updatedAt, updatedBy
/users: user records; প্রতিটি রেকর্ডে enabled ফিল্ড থাকলে UI থেকে পরিবর্তন করা যাবে (Rules অনুমতি দিলে)।

গুরুত্বপূর্ণ নিরাপত্তা:
- নিচের উদাহরণটি ব্যবহার করার আগে নিজের ADMIN_UID বসান। Authentication-এর Users তালিকা থেকে admin user-এর UID নিন।
- Realtime Database Rules-এ adminSettings ও remoteSettings কেবল ঐ UID-কে read/write অনুমতি দিন।
- /users-এর ক্ষেত্রে নিজের অ্যাপের প্রয়োজন অনুযায়ী নিয়ম লিখুন; সাধারণ ব্যবহারকারীকে অন্য ব্যবহারকারীর রেকর্ড পরিবর্তনের অনুমতি দেবেন না।
- নিচের rules পুরোপুরি প্রয়োগ করার আগে নিশ্চিত করুন আপনার user data structure-এর সাথে মেলে।

Realtime Database Rules উদাহরণ (ADMIN_UID বদলাতে হবে):
{
  "rules": {
    "adminSettings": {
      ".read": "auth != null && auth.uid === 'ADMIN_UID'",
      ".write": "auth != null && auth.uid === 'ADMIN_UID'"
    },
    "remoteSettings": {
      ".read": "auth != null && auth.uid === 'ADMIN_UID'",
      ".write": "auth != null && auth.uid === 'ADMIN_UID'"
    },
    "users": {
      ".read": "auth != null && auth.uid === 'ADMIN_UID'",
      "$uid": { ".write": "auth != null && auth.uid === 'ADMIN_UID'" }
    }
  }
}

নোট:
- এই প্যানেল কেবল সেই অ্যাপগুলো নিয়ন্ত্রণ করবে যেগুলো একই Firebase Database-এর /adminSettings ও /remoteSettings পড়ে এবং এই সেটিংস অনুযায়ী কাজ করার জন্য কোড করা হয়েছে। অন্য যেকোনো APK স্বয়ংক্রিয়ভাবে নিয়ন্ত্রণ করতে পারবে না।
- Firebase JS SDK CDN থেকে লোড হয়, তাই ইন্টারনেট প্রয়োজন।
- Animation বন্ধ থাকলেও ডিভাইস/নেটওয়ার্ক/ডেটাবেসের কারণে ধীরগতি হতে পারে।
